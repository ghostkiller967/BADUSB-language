﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace BADUSB
{
    public partial class Form1 : Form
    {
        string dir = "./";
        string filename = "script.txt";
        string finaldir;
        string line = "";
        string String;
        string StringHold;
        string Delay;
        string defaultDelay;
        string downloadfile;
        string processlocation;
        string deletefilelocation;
        string deletedirlocation;
        string createdirlocation;
        string createfilelocation;
        string filelocation;
        string contents;

        string var;

        int defaultdelay = 100;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dir = "./";
            filename = "script.txt";
            finaldir = "";
            line = "";
            String = "";
            Delay = "";
            finaldir = dir + "/" + filename;
            StreamReader sr = new StreamReader(finaldir);
            string first = sr.ReadLine();

            defaultDelay = first;
            defaultDelay = defaultDelay.Remove(0, 13);
            defaultdelay = Int32.Parse(defaultDelay);
            
            while (line != null)
            {
                line = sr.ReadLine();
                if (line != null)
                {
                    Thread.Sleep(defaultdelay);
                    if (line.StartsWith("STRING "))
                    {
                        String = line;
                        String = String.Remove(0, 7);
                        if (String == "VAR")
                        {
                            SendKeys.Send(var);
                        } else
                        {
                            SendKeys.Send(String);
                        }
                    }

                    if (line.StartsWith("STRINGWAIT "))
                    {
                        StringHold = line;
                        StringHold = StringHold.Remove(0, 11);
                        SendKeys.SendWait(StringHold);
                    }

                    if (line.StartsWith("DELAY "))
                    {
                        Delay = line;
                        Delay = Delay.Remove(0, 6);
                        int delay = Int32.Parse(Delay);
                        Thread.Sleep(delay);
                    }

                    if (line.StartsWith("DOWNLOADFILE "))
                    {
                        WebClient wc = new WebClient();
                        downloadfile = line;
                        downloadfile = downloadfile.Remove(0, 13);

                        wc.DownloadFile(downloadfile, filelocation);
                    }

                    if (line.StartsWith("STARTPROCESS "))
                    {
                        processlocation = line;
                        processlocation = processlocation.Remove(0, 13);
                        Process.Start(processlocation);
                    }

                    if (line.StartsWith("RUNPROMPT"))
                    {
                        string userName = Environment.UserName;
                        Process.Start($"C:/Users/{userName}/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/System Tools/Run.lnk");
                    }

                    if (line.StartsWith("CMD"))
                    {
                        string userName = Environment.UserName;
                        Process.Start($"C:/Users/{userName}/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/System Tools/Command Prompt.lnk");
                    }

                    if (line.StartsWith("ENTER"))
                    {
                        SendKeys.Send("{ENTER}");
                    }

                    if (line.StartsWith("MENU"))
                    {
                        SendKeys.SendWait("+{F10}");
                    }

                    if (line.StartsWith("GUI"))
                    {
                        SendKeys.SendWait("^{ESC}");
                    }

                    if (line.StartsWith("DELETEFILE "))
                    {
                        deletefilelocation = line;
                        deletefilelocation = deletefilelocation.Remove(0, 11);
                        File.Delete(deletefilelocation);
                    }

                    if (line.StartsWith("DELETEDIR "))
                    {
                        deletedirlocation = line;
                        deletedirlocation = deletedirlocation.Remove(0, 10);
                        Directory.Delete(deletedirlocation, true);
                    }

                    if (line.StartsWith("CREATEDIR "))
                    {
                        createdirlocation = line;
                        createdirlocation = createdirlocation.Remove(0, 10);
                        Directory.CreateDirectory(createdirlocation);
                    }

                    if (line.StartsWith("CREATEFILE "))
                    {
                        createfilelocation = line;
                        createfilelocation = createfilelocation.Remove(0, 11);
                        File.Create(createfilelocation);
                    }

                    if (line.StartsWith("EDITFILE "))
                    {
                        contents = line;
                        contents = contents.Remove(0, 9);
                        File.WriteAllText(filelocation, contents);
                    }

                    if (line.StartsWith("SETLOCATION "))
                    {
                        filelocation = line;
                        filelocation = filelocation.Remove(0, 12);
                    }

                    if (line.StartsWith("VAR "))
                    {
                        var = line;
                        var = var.Remove(0, 4);
                    }
                }
            }
            sr.Close();
            Application.Exit();
        }
    }
}